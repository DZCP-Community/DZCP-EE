<?php
ob_start();
ob_implicit_flush(false);
define('basePath', dirname(dirname(__FILE__).'../'));

function getmicrotime()
{
	list($usec,$sec) = explode(" ",microtime());
	return((float)$usec+(float)$sec);
}

$time_start=getmicrotime();

function can_gzip()
{
	if(headers_sent() || connection_aborted())
		return false;
		
	if(!function_exists('gzcompress'))
		return false;
		
	if(strpos($_SERVER['HTTP_ACCEPT_ENCODING'],'gzip') !== true)
		return false;
		
	return true;
}

function gz_output()
{
	$html = trim(ob_get_contents());
	$gzip_compress_level = (!defined('buffer_gzip_compress_level') ? 4 : buffer_gzip_compress_level);
	$gzip_compress = (!defined('buffer_gzip_compress') ? true : buffer_gzip_compress);
	@ini_set('zlib.output_compression_level', $gzip_compress_level); 
	
	ob_end_clean();
	ob_start('ob_gzhandler');
	
	if(can_gzip() && $gzip_compress)
		echo $html."\r\n\r\n"."<!-- [GZIP enabled => Level ".$gzip_compress_level."] ".sprintf("%01.2f",((strlen(gzcompress($html,$gzip_compress_level)))/1024))." kBytes | uncompressed: ".sprintf("%01.2f",((strlen($html))/1024 ))." kBytes -->";
	else
		echo $html."\r\n\r\n"."<!-- [GZIP disabled] -->";
	
	ob_end_flush();
	exit();
}